inherit ROOM;                                                        

void create ()
{
  set ("short", "������" );   

    set("exits", ([ 
               "southwest" : __DIR__"lie",
                  ]));
    set("objects", ([ 
               __DIR__"npc/leishen" : 1,
                  ]));
    setup();
}
